"""PubMed CLI Package.

Provides modules to fetch, filter, and export PubMed data.
"""